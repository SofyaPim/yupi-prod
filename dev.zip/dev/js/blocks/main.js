"use strict";
//  import Swiper from "../lib/swiper.min.js";

// fix header
function fixheader() {
  const main = document.querySelector(".main");
  const header = document.querySelector(".header");
  window.addEventListener("scroll", () => {
    let scrollTop = window.scrollY;
    let mainCenter = main.offsetHeight / 2;
    scrollTop >= mainCenter
      ? header.classList.add("fixed")
      : header.classList.remove("fixed");
  });
}

// mobile navigation
function navBurger() {
  const btn = document.querySelector(".menu__burger-btn");
  btn.addEventListener("click", function () {
    document.querySelector(".header").classList.toggle("open");
  });
}

//
function moreAboutUs() {
  // const overlay = document.querySelector(".overlay");
  // let itemForBlur = document.querySelector(".more-info");
  let cards = document.querySelectorAll(".more-info__items-card");
  let overlayImg = document.querySelectorAll(".more-info__items-overlay");
  let body = document.querySelector("body");

  overlayImg.forEach((item) => {
    item.classList.add("displayNone");
    item.addEventListener("click", (e) => {
      e.currentTarget.classList.add("displayNone");
      body.style.overflow = "scroll";
    });
  });

  cards.forEach((item) => {
    item.addEventListener("click", (e) => {
      e.currentTarget.nextElementSibling.classList.remove("displayNone");
      body.style.overflow = "hidden";
      console.log(e.currentTarget.nextElementSibling);
    });
  });
}

//========rotate stories
function scrollStorys() {
  const peopleBlock = document.querySelector(".yupi-people");
  const peopleStoryLeft = document.querySelector(
    ".yupi-people__block-row.left"
  );
  const peopleStoryRight = document.querySelector(
    ".yupi-people__block-row.right"
  );
  window.addEventListener("scroll", () => {
    let peopleBlockTop = peopleBlock.getBoundingClientRect().top;
    let peopleBlockHeight = peopleBlock.clientHeight;

    if (peopleBlockTop <= 0 && peopleBlockTop <= peopleBlockHeight / 3) {
      peopleStoryLeft.classList.toggle("left");
      peopleStoryRight.classList.toggle("right");
    }
  });
}
// show desc for years
function showYears(desktopSelector) {
  desktopSelector = document.querySelector(".progress__years.desktop");
  let lines = desktopSelector.querySelectorAll(".line");
  let parags = desktopSelector.querySelectorAll(".progress__years-desc.item p");
  let bgs = desktopSelector.querySelectorAll(".progress__years-bg");
  let items = desktopSelector.querySelectorAll(".progress__years-desc.item");
  lines.forEach((line) => {
    line.classList.add("addOpacity");
  });
  bgs.forEach((item) => {
    item.classList.remove("addBG");
  });
  parags.forEach((item) => {
    item.classList.add("addOpacity");
  });
  items.forEach((item) => {
    item.addEventListener("mouseover", (e) => {
      let div = e.currentTarget.closest(".progress__years-desc.item");
      div.firstElementChild.classList.remove("addOpacity");
      div.lastElementChild.classList.add("addBg");
      div.lastElementChild.lastElementChild.classList.remove("addOpacity");
    });
    item.addEventListener("mouseout", (e) => {
      let div = e.currentTarget.closest(".progress__years-desc.item");
      div.firstElementChild.classList.add("addOpacity");
      div.lastElementChild.classList.remove("addBg");
    });
  });
}

document.addEventListener("DOMContentLoaded", function () {
  const yupi = new Swiper(".yupi-people-slider", {
    slidesPerView: 3,
    spaceBetween: -10,
    // navigation: {
    //   nextEl: ".swiper-button-next",
    //   prevEl: ".swiper-button-prev",
    // },
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
    },
    loop: true,

    breakpoints: {
      // when window width is >= 320px
      320: {
        slidesPerView: 2.5,
        spaceBetween: 10,
      },
      // when window width is >= 480px
      480: {
        slidesPerView: 3,
        spaceBetween: 10,
      },
     
    },
  });
  const years = new Swiper(".years-swiper", {
    slidesPerView: 2,
    spaceBetween: 10,
    loop: true,

    breakpoints: {
      320: {
        slidesPerView: 1.5,
        spaceBetween: 20,
      },
      480: {
        slidesPerView: 2.5,
        spaceBetween: 30,
      },
    },
  });
  const moreInfo = new Swiper(".more-info-slider", {
    // slidesPerView: 4,
    spaceBetween: 10,
    loop: true,

    breakpoints: {
      320: {
        slidesPerView: 1.5,
        spaceBetween: 20,
      },
      480: {
        slidesPerView: 2.5,
        spaceBetween: 30,
      },
    },
  });
  const technologies = new Swiper(".technologies__block-slider", {
     spaceBetween: 10,
     breakpoints: {
      320: {
        slidesPerView: 1.1,
        
      },
      739: {
        slidesPerView: 3,
      },
    },
  });
  const releases = new Swiper(".releases__block-slider", {
    spaceBetween: 10,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      type: "bullets",
    },

    breakpoints: {
      320: {
        slidesPerView: 1,
      },
      739: {
        slidesPerView: 3,
      },
    },
  });

  navBurger();
  fixheader();
  scrollStorys();
  showYears();
  moreAboutUs();
});
